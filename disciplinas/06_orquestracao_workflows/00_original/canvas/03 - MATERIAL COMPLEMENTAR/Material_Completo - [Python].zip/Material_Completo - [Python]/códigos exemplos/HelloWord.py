class Student:
    school_name = 'RaroLabs' # Variável de Classe

    def __init__(self, name, age):
        self.name = name
        self.age = age

    # parametro CLS faz referência para classe
    @classmethod
    def change_school(cls, name):
        cls.school_name = name
        print(cls.school_name) # acessando a variável de classe


object_aluno =Student('João silvero', 18)
object_aluno.change_school('Una Aymores')