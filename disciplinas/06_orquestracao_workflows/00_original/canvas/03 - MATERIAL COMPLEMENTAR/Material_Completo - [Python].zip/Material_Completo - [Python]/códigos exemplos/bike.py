class Bike:
    def __init__(self) -> None:
        self.marchas = 1
        self.aro = 20
        
    def subir_marcha(self):
        self.marchas += 1
    def descer_marcha(self):
        self.marchas -= 1
        
    def show(self):
        print(f"Essa bike está andando na {self.marchas}º e ela possuí aro {self.aro}")