# from bike import Bike
# from mount_bike import MountBike

# bicletinha = Bike()

# bicletinha.show()

# bicletinha.subir_marcha()
# bicletinha.subir_marcha()

# bicletinha.show()

# bike_trilha = MountBike()

# bike_trilha.show()


# Classe Base
# class Company:
#     def __init__(self):
#         # Protected member
#         self._project = "MFA - App Call Center"
#         self.__onwer = "joão"

# # Classe Filha
# class Employee(Company):
#     def __init__(self, name):
#         self.name = name
#         Company.__init__(self)

#     def show(self):
#         print("Nome Funcionário :", self.name)
#         # Accessing protected member in child class
#         print("Trabalhando no projeto :", self._project)

# empregado_aristela = Employee("Aristela")
# empregado_aristela.show()


# c = Company()
# # Direct access protected data member
# print('Projeto:', c._project)

# class Employee:
#     salary = 60000
    
#     def show_salary(self):
#         print(f'Salário mensal é de {self.salary}')
        
#     def get_salary(self):
#         return self.salary

# class Engineer(Employee):
#     def __init__(self):
#         self.bonus = 10000
    
#     def show_salary_full(self):
#         print(f'Salário + bónus é de {super().salary + self.bonus}')


# empregado = Engineer()

# empregado.show_salary()

# class Employee:
#     salary = 60000
    
#     def show_salary(self):
#         print(f'Salário mensal é de {self.salary}')

# class Engineer(Employee):
#     def __init__(self):
#         self.bonus = 10000

#     def show_bonus(self):
#         print(f'Bonus é de {self.bonus}')


# empregado = Engineer()

# empregado.show_salary()
# empregado.show_bonus()

# Classe Pai 1
# class Person:
#     def __init__(self, name: str, age: int, **kwargs):
#         self.name_person = name
#         self.age_person = age

# # Classe Pai 2
# class Company:
#     def __init__(self, company_name: str, location: str):
#         self.company_name = company_name
#         self.location_company = location

# # Classe Filha
# class Employee(Person, Company):
#     def __init__(self, salary: int, skill: str, name_person: str, age_person: int, name_company: str, location_company: str):
#         self.salary = salary
#         self.skill = skill
        
#         # 
#         super.__init__(Company, name_person, age_person)
#         super.__init__(Employee, name_company, location_company)



# objeto_empregado = Employee(1200, 'reinaldo mendes', 'data science',23, 'google', 'belo horizonte')

# # Acessando Dados
# objeto_empregado.person_info('Miguel Antônio', 42)
# objeto_empregado.company_info('Google', 'Belo Horizonte')
# objeto_empregado.Employee_info(12000, 'Machine Learning')

# class Student:
#     school_name = 'RaroLabs' # Variável de Classe

#     def __init__(self, name, age):
#         self.name = name
#         self.age = age

#     # parametro CLS faz referência para classe
#     @classmethod
#     def change_school(cls, name):
#         Student.school_name = name
#         print(Student.school_name) # acessando a variável de classe

# objeto_estudante = Student('Alberto Silva', 17)
# Student.change_school('Raro Academy - Python') # Chamada método de classe

# class Employee(object):

#     def __init__(self, name, project_name):
#         self.name = name
#         self.project_name = project_name

#     # Método Estático
#     @staticmethod
#     def gather_requirement(project_name):
#         if project_name == 'Migração de dados':
#             requirement = ['tarefa 1', 'tarefa 2', 'tarefa 3']
#         else:
#             requirement = ['tarefa 1']
#         return requirement

#     # Método de Instância
#     def work(self):
#         # Chamando um método estático dentro de um método de instância
#         requirement = self.gather_requirement(self.project_name)
#         for task in requirement:
#             print('Finalizada ', task)

# emp = Employee('Kelly', 'Machine Learning')
# emp.work()

# emp_2 = Employee('Luiz', 'Migração de dados')
# emp_2.work()

class Employee:
    def sample(x):
        print('Dentro do método convertido para estático', x)

# Converte o método para estático
Employee.sample = staticmethod(Employee.sample)

# chamando método estático
Employee.sample(10)