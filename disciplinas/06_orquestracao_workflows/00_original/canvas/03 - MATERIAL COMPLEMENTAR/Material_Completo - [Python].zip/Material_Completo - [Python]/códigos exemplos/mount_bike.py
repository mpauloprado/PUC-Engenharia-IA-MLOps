class MountBike():
    def __init__(self) -> None:
        self.aro_roda = 17
        self.cor_roda = "preto"
    def show(self):
        print(f"A cor da roda é {self.cor_roda}\nÉ uma mount bike de aro {self.aro_roda}")
